# Adding articles to m365architect.in

This starter website is a static website. You can publish articles as individual HTML pages without needing a database or paid CMS.

## Publish a new article
1. Copy `articles/article-template.html`.
2. Rename the copy using a short URL-friendly name, for example `microsoft-365-copilot-readiness.html`.
3. Replace ARTICLE TITLE, ARTICLE CATEGORY, DATE and the sample text.
4. Add your screenshots or diagrams to the `assets` folder and update the image path in your article.
5. Add a new article card in the Articles section of `index.html`. Copy one of the existing `<article class="article">...</article>` blocks and update its title, summary, category and image.
6. Upload/commit the changed files to your hosting provider. The site will redeploy.

## Suggested article categories
- Microsoft 365 Security & Compliance
- Microsoft Entra ID & Identity
- Microsoft Intune & Endpoint Management
- Microsoft 365 Copilot Readiness
- Mimecast & Email Security
- Tenant Migration & Architecture
- PowerShell & Automation

## Writing tips
- Start with the business or technical problem.
- State the Microsoft 365 workload and relevant prerequisites.
- Use numbered steps for implementation guides.
- Include PowerShell code in code blocks and explain what it does.
- Add validation, rollback and troubleshooting notes.
- Link to official Microsoft or vendor documentation.
- Remove customer names, tenant IDs, email addresses, IP addresses, screenshots with personal data and confidential configuration before publishing.
- Do not publish customer information or proprietary scripts without permission.

## Files
- `index.html`: main portfolio and article cards
- `articles/article-template.html`: reusable article page
- `assets/`: hero and article illustrations
- `Naveen_IT_M365_Solution_Architect.pdf`: CV download
- `CNAME`: custom domain mapping
